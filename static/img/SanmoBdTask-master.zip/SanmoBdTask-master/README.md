This task was completed by following the documentation below.
------------------------------------------------------------------------
Build a Simple Project for SanMo Bangladesh with Python Django
Task Timeline: 30 Sep 2024
Admin Part:
1) Admin Authentication with Username and Password
2) Product Functionalities (Add, Update, Show, Delete)
3) Product Field
a) Name
b) Description
c) Featured Image
d) Price
e) Discount Price
f) Status
Frontend Part:
1) Show Product in 2 Segments
a) Product Price Under 200
b) Product Price Up to 200
2) Single Product View with All Product Information.
-----------------------------------------------------------------------

This web app was built with Django and Mysql follow the rquirments.text to see specific version.
